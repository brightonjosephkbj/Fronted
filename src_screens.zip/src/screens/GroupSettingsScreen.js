import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Switch, Modal, Pressable } from 'react-native';
import { BlurView } from '@react-native-community/blur';
import { useRoute, useNavigation } from '@react-navigation/native';
import { ChevronLeft, ChevronRight, BadgeCheck, Link2, QrCode } from 'lucide-react-native';
import { useAuth } from '../context/AuthContext';

const MEMBERS = [
  { id: '1', name: 'Henry', color: '#4f46e5', role: 'owner', verified: 'purple' },
  { id: '2', name: 'Derrick', color: '#f97316', role: 'admin', verified: null },
  { id: '3', name: 'Rita', color: '#db2777', role: 'member', verified: null },
];

function verifiedColor(tick) {
  if (tick === 'cyan') return '#06b6d4';
  if (tick === 'blue') return '#3b82f6';
  return '#a855f7';
}

function MemberAvatar({ name, color, verified, size = 32 }) {
  const badgeSize = Math.max(12, Math.round(size * 0.36));
  return (
    <View style={{ width: size, height: size }}>
      <View style={[styles.memberDot, { width: size, height: size, borderRadius: size / 2, backgroundColor: color }]}>
        <Text style={styles.memberDotText}>{name[0]}</Text>
      </View>
      {verified && (
        <View style={[
          styles.verifiedBadge,
          { width: badgeSize, height: badgeSize, borderRadius: badgeSize / 2, backgroundColor: verifiedColor(verified), top: -badgeSize * 0.15, right: -badgeSize * 0.15 },
        ]}>
          <BadgeCheck size={badgeSize * 0.6} color="#fff" strokeWidth={3} />
        </View>
      )}
    </View>
  );
}

function GlassCard({ style, children, blurAmount = 18, tint = 0.35 }) {
  return (
    <View style={[styles.glassWrap, style]}>
      <BlurView style={StyleSheet.absoluteFill} blurType="light" blurAmount={blurAmount} />
      <View style={[StyleSheet.absoluteFillObject, { backgroundColor: `rgba(255,255,255,${tint})` }]} />
      {children}
    </View>
  );
}

function NavRow({ label, sub, onPress, last }) {
  return (
    <TouchableOpacity style={[styles.row, last && styles.rowLast]} onPress={onPress}>
      <Text style={[styles.rowLabel, { flex: 1 }]}>{label}</Text>
      {sub && <Text style={styles.rowSub}>{sub}</Text>}
      <ChevronRight size={16} color="#9ca3af" style={{ marginLeft: 6 }} />
    </TouchableOpacity>
  );
}

function ToggleRow({ label, value, onChange, last }) {
  return (
    <View style={[styles.row, last && styles.rowLast]}>
      <Text style={[styles.rowLabel, { flex: 1 }]}>{label}</Text>
      <Switch value={value} onValueChange={onChange} />
    </View>
  );
}

export default function GroupSettingsScreen() {
  const route = useRoute();
  const navigation = useNavigation();
  const { user } = useAuth();
  const group = route.params?.group || { name: 'Group', color: '#4f46e5', description: '' };

  const [members, setMembers] = useState(MEMBERS);
  const [sendPerm, setSendPerm] = useState(true);
  const [editPerm, setEditPerm] = useState(false);
  const [antiDelete, setAntiDelete] = useState(false);
  const [actionSheetMember, setActionSheetMember] = useState(null);

  const myRole = members.find(m => m.name === user?.username)?.role || 'member';
  const isOwner = myRole === 'owner';
  const isAdmin = myRole === 'admin' || isOwner;

  function canManage(target) {
    if (target.role === 'owner') return false;
    if (target.role === 'admin') return isOwner;
    return isAdmin;
  }

  function handleMemberPress(m) {
    if (!canManage(m)) return;
    setActionSheetMember(m);
  }

  function promote(m) {
    setMembers(prev => prev.map(x => x.id === m.id ? { ...x, role: 'admin' } : x));
    setActionSheetMember(null);
  }
  function demote(m) {
    setMembers(prev => prev.map(x => x.id === m.id ? { ...x, role: 'member' } : x));
    setActionSheetMember(null);
  }
  function remove(m) {
    setMembers(prev => prev.filter(x => x.id !== m.id));
    setActionSheetMember(null);
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: 14 }}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtnWrap}>
          <BlurView style={StyleSheet.absoluteFill} blurType="light" blurAmount={14} />
          <ChevronLeft size={22} color="#0f0f1a" />
        </TouchableOpacity>
        <Text style={styles.title}>Group Settings</Text>
      </View>

      <GlassCard style={styles.profileCard} tint={0.4}>
        <View style={[styles.groupAvatar, { backgroundColor: group.color }]}>
          <Text style={styles.groupAvatarText}>{group.name[0]}</Text>
        </View>
        <Text style={styles.groupName}>{group.name}</Text>
        {!!group.description && <Text style={styles.groupDesc}>{group.description}</Text>}
        <Text style={styles.memberCount}>{members.length} members</Text>
      </GlassCard>

      <Text style={styles.sectionTitle}>Members</Text>
      <GlassCard style={{ padding: 0 }}>
        {members.map((m, i) => (
          <TouchableOpacity
            key={m.id}
            style={[styles.row, i === members.length - 1 && styles.rowLast]}
            onPress={() => handleMemberPress(m)}
            activeOpacity={canManage(m) ? 0.6 : 1}
          >
            <MemberAvatar name={m.name} color={m.color} verified={m.verified} />
            <Text style={{ flex: 1, fontWeight: '600', marginLeft: 10, color: '#0f0f1a' }}>{m.name}</Text>
            {m.role !== 'member' && <Text style={styles.roleBadge}>{m.role}</Text>}
          </TouchableOpacity>
        ))}
      </GlassCard>

      <Text style={styles.sectionTitle}>Permissions</Text>
      <GlassCard style={{ padding: 0 }}>
        <ToggleRow label="Who can send messages" value={sendPerm} onChange={setSendPerm} />
        <ToggleRow label="Who can edit group info" value={editPerm} onChange={setEditPerm} last />
      </GlassCard>

      <Text style={styles.sectionTitle}>Invite</Text>
      <GlassCard style={{ padding: 0 }}>
        <TouchableOpacity style={styles.row}>
          <Link2 size={16} color="#4338ca" />
          <Text style={[styles.rowLabel, { marginLeft: 10 }]}>Invite link</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.row, styles.rowLast]}>
          <QrCode size={16} color="#4338ca" />
          <Text style={[styles.rowLabel, { marginLeft: 10 }]}>QR code</Text>
        </TouchableOpacity>
      </GlassCard>

      <Text style={styles.sectionTitle}>Appearance</Text>
      <GlassCard style={{ padding: 0 }}>
        <NavRow label="Wallpaper" sub="Papercut" onPress={() => {}} />
        <NavRow label="Chat color" onPress={() => {}} last />
      </GlassCard>

      <Text style={styles.sectionTitle}>Privacy & Security</Text>
      <GlassCard style={{ padding: 0 }}>
        <ToggleRow label="Anti-delete messages" value={antiDelete} onChange={setAntiDelete} />
        <NavRow label="Disappearing messages" sub="Off" onPress={() => {}} last />
      </GlassCard>

      <Text style={styles.sectionTitle}>Data</Text>
      <GlassCard style={{ padding: 0 }}>
        <NavRow label="Media, links & docs" onPress={() => {}} />
        <NavRow label="Search within chat" onPress={() => {}} last />
      </GlassCard>

      <Text style={[styles.sectionTitle, { color: '#ef4444' }]}>Danger Zone</Text>
      <GlassCard style={{ padding: 0 }}>
        <TouchableOpacity style={styles.row}><Text style={styles.dangerText}>Mute notifications</Text></TouchableOpacity>
        <TouchableOpacity style={styles.row}><Text style={styles.dangerText}>Clear chat history</Text></TouchableOpacity>
        <TouchableOpacity style={styles.row}><Text style={styles.dangerText}>Exit group</Text></TouchableOpacity>
        {isOwner && (
          <TouchableOpacity style={styles.row}><Text style={styles.dangerText}>Delete group</Text></TouchableOpacity>
        )}
        <TouchableOpacity style={[styles.row, styles.rowLast]}><Text style={styles.dangerText}>Report group</Text></TouchableOpacity>
      </GlassCard>

      <View style={{ height: 30 }} />

      <Modal visible={!!actionSheetMember} transparent animationType="fade" onRequestClose={() => setActionSheetMember(null)}>
        <Pressable style={styles.sheetBackdrop} onPress={() => setActionSheetMember(null)}>
          <GlassCard style={styles.sheet} blurAmount={24} tint={0.55}>
            {actionSheetMember && (
              <>
                <View style={styles.sheetHeader}>
                  <MemberAvatar name={actionSheetMember.name} color={actionSheetMember.color} verified={actionSheetMember.verified} size={36} />
                  <Text style={styles.sheetHeaderText}>{actionSheetMember.name}</Text>
                </View>
                {actionSheetMember.role === 'member' && isAdmin && (
                  <TouchableOpacity style={styles.sheetItem} onPress={() => promote(actionSheetMember)}>
                    <Text style={styles.sheetItemText}>Make admin</Text>
                  </TouchableOpacity>
                )}
                {actionSheetMember.role === 'admin' && isOwner && (
                  <TouchableOpacity style={styles.sheetItem} onPress={() => demote(actionSheetMember)}>
                    <Text style={styles.sheetItemText}>Remove as admin</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity style={styles.sheetItem} onPress={() => remove(actionSheetMember)}>
                  <Text style={[styles.sheetItemText, { color: '#ef4444' }]}>Remove from group</Text>
                </TouchableOpacity>
              </>
            )}
          </GlassCard>
        </Pressable>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#eef2ff' },
  glassWrap: { overflow: 'hidden', borderRadius: 20, borderWidth: 1, borderColor: 'rgba(255,255,255,0.6)', marginBottom: 16 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 14 },
  backBtnWrap: { width: 38, height: 38, borderRadius: 19, overflow: 'hidden', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.6)' },
  title: { fontSize: 16, fontWeight: '700' },
  profileCard: { padding: 22, alignItems: 'center', gap: 4 },
  groupAvatar: { width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center' },
  groupAvatarText: { color: 'white', fontSize: 26, fontWeight: '700' },
  groupName: { fontSize: 16, fontWeight: '800', marginTop: 8, color: '#0f0f1a' },
  groupDesc: { fontSize: 12.5, color: '#6b6b7a', textAlign: 'center' },
  memberCount: { fontSize: 12, color: '#9ca3af' },
  sectionTitle: { fontSize: 11.5, fontWeight: '700', color: '#6b6b7a', marginBottom: 6, marginLeft: 4, marginTop: 4, textTransform: 'uppercase' },
  row: { flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.4)' },
  rowLast: { borderBottomWidth: 0 },
  rowLabel: { fontSize: 14, fontWeight: '600', color: '#0f0f1a' },
  rowSub: { fontSize: 12, color: '#9ca3af', marginLeft: 'auto' },
  memberDot: { alignItems: 'center', justifyContent: 'center' },
  memberDotText: { color: 'white', fontWeight: '700' },
  verifiedBadge: { position: 'absolute', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#ffffff' },
  roleBadge: { fontSize: 10.5, fontWeight: '700', color: '#4f46e5', textTransform: 'capitalize' },
  dangerText: { color: '#ef4444', fontWeight: '600' },
  sheetBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  sheet: { borderTopLeftRadius: 20, borderTopRightRadius: 20, borderBottomWidth: 0, marginBottom: 0, paddingVertical: 10 },
  sheetHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 20, paddingBottom: 14, marginBottom: 6, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.4)' },
  sheetHeaderText: { fontWeight: '700', fontSize: 15, color: '#0f0f1a' },
  sheetItem: { paddingVertical: 13, paddingHorizontal: 20 },
  sheetItemText: { fontSize: 14.5, color: '#0f0f1a' },
});
